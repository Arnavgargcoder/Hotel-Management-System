package hotelmangement;

import hotelmangement.splashscreen.SplashScreen;

public class HotelMangement {

    public static void main(String[] args) {
        new SplashScreen().setVisible(true);
    }
}
